<?php
    $Name = $_POST['name'];
    $DOB = $_POST['dob'];
    $Age = $_POST['age'];
    $Occupation = $_POST['occupation'];
    $Add = $_POST['addr'];
    $B_group = $_POST['b_group'];
    $Weight = $_POST['wt'];
    // $Weight = $_POST['weight'];
    $Bp = $_POST['blood_pressure'];
    // $Bp = $_POST['blood_pressure'];
    // $Bp = $_POST['blood_pressure'];
    $sex = $_POST['sex'];
    // $sex = $_POST['sex'];
    $marital_status = $_POST['marital_status'];
    // $marital_status = $_POST['marital_status'];
    $Fname = $_POST['fname'];
    $Org = $_POST['org'];
    $Pno = $_POST['pno'];
    $Dept = $_POST['dept'];
    $Tel = $_POST['telephone'];
    $Mobile = $_POST['mobile'];
    $Prate = $_POST['prate'];
    $Hb = $_POST['hb'];
    // $Hb = $_POST['hb'];
    $Temp = $_POST['temprature'];
    // $Temp = $_POST['temprature'];
    $Understand = $_POST['understand'];
    $Donated = $_POST['donated'];
    $Times = $_POST['times'];
    $D_date = $_POST['d_date'];
    $Feel = $_POST['feel'];
    $Eat = $_POST['eat'];
    $Sleep = $_POST['sleep'];
    $Reason = $_POST['reason'];
    $sixm = $_POST['sixm'];
    $Any = $_POST['any'];
    $Suffer = $_POST['suffer'];
    $Surgery = $_POST['surgery'];
    $Pregnent = $_POST['pregnent'];
    $Child = $_POST['child'];
    $Feeding = $_POST['feeding'];
    $Abortion = $_POST['abortion'];
    $Period = $_POST['period'];
    $Abnormal = $_POST['abnormal'];
    $Information = $_POST['information'];
    $Plasma = $_POST['plasma'];
    $Today_date = $_POST['today_date'];
    $Today_time = $_POST['today_time'];


    //Database connection

    $servername = "localhost:3307";
    $username = "root";
    $password = "";
    $db="register";

    // Create connection
    $conn = new mysqli($servername, $username, $password,$db);

    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully";

    $sql = "INSERT INTO user_details(name , dob, age , occupation , addr , b_group , wt )
    VALUES ('$Name', '$DOB', '$Age', '$Occupation' ,'$Add', '$B_group', '$Weight')";

    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();


?>