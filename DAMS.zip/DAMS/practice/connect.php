<?php
    $name = $_POST['name'];
    $Email = $_POST['Email'];
    $password = $_POST['password'];

    // database connection code
    $conn = new mysqli('localhost','root','',login)
    if($conn->connection_error){
        die('Connection Failed : '.$conn->connect_error)
    }
    else{
        $stmt=$conn->prepare("insert into registration(name,email,password)values(?,?,?)");
        $stmt->bind_para("sss",$name,$email,$password);
        $stmt->execute();
        echo "Registration successful...";
        $stmt->close();
        $conn->close();
    }

?>