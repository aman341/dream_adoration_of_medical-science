<?php
    $Name = $_POST['name'];
    $DOB = $_POST['dob'];
    $Age = $_POST['age'];
    $Occupation = $_POST['occupation'];
    $Add = $_POST['add'];
    $B_group = $_POST['b_group'];
    $Weight = $_POST['weight'];
    $Weight = $_POST['weight'];
    $Bp = $_POST['blood_pressure'];
    $Bp = $_POST['blood_pressure'];
    $Bp = $_POST['blood_pressure'];
    $sex = $_POST['sex'];
    $sex = $_POST['sex'];
    $marital_status = $_POST['marital_status'];
    $marital_status = $_POST['marital_status'];
    $Fname = $_POST['fname'];
    $Org = $_POST['org'];
    $Pno = $_POST['pno'];
    $Dept = $_POST['dept'];
    $Tel = $_POST['telephone'];
    $Mobile = $_POST['mobile'];
    $Prate = $_POST['prate'];
    $Hb = $_POST['hb'];
    $Hb = $_POST['hb'];
    $Temp = $_POST['temprature'];
    $Temp = $_POST['temprature'];
    $Understand = $_POST['understand'];
    $Donated = $_POST['donated'];
    $Times = $_POST['times'];
    $D_date = $_POST['d_date'];
    $Feel = $_POST['feel'];
    $Eat = $_POST['eat'];
    $Sleep = $_POST['sleep'];
    $Reason = $_POST['reason'];
    $sixm = $_POST['sixm'];
    $Any = $_POST['any'];
    $Suffer = $_POST['suffer'];
    $Surgery = $_POST['surgery'];
    $Pregnent = $_POST['pregnent'];
    $Child = $_POST['child'];
    $Feeding = $_POST['feeding'];
    $Abortion = $_POST['abortion'];
    $Period = $_POST['period'];
    $Abnormal = $_POST['abnormal'];
    $Information = $_POST['information'];
    $Plasma = $_POST['plasma'];
    $Today_date = $_POST['today_date'];
    $Today_time = $_POST['today_time'];

    ob_start();
    
    require('fpdf/fpdf.php');
    
    // require_once("library/tcpdf.php");

$pdf = new FPDF();

// $pdf->SetY(223);

// $pdf->SetTextColor(0,171,89);

// $pdf->SetFont('Times','BI',18);

// $pdf->Cell(0,5,'Board of Director', 0,1,'L');

$pdf->AddPage();
    
$pdf->SetFont('Arial','B',18);
    $pdf->Cell(0,15,'BLOOD DONOR QUESTIONNAIRE & CONSET FORM',0,1,'C');
    $pdf->Cell(0,15,"Rajendra Institute of Medical Sciences (RIMS)",0,1,'C');

    $pdf->SetFont('Arial','',14);
    $pdf->Cell(130,10,"Bariatu, Ranchi - 834009, Jharkhand",0,0,'R');
    
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(33,10,"Date :",0,1,'C');
    $pdf->Cell(0,15,"Phone No. 0651-2540565",0,1,'C');

    $pdf->SetFont('Arial','',12);
    $pdf->Cell(80,10,"License No. : JH/BB/14/2006",0,0);
    $pdf->Cell(25,10,"ID card No. :",0,0);
    $pdf->Cell(35,10,$Id,0,0);
    $pdf->Cell(30,10,"Blood Unit No. :",0,0,'C');
    $pdf->Cell(0,10,$Blood,0,1);


    $pdf->SetFont('Arial','B',18);
    $pdf->Cell(0,20,"Confidential",0,1,'C');


//Form Part
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,3,"TICK WHERE EVER APPLICABLE  PLEASE ANSWER  FOLLOWING  QUESTIONS  CORRECTLY. ",0,1);
$pdf->Cell(0,12,"THIS WILL HELP TO PROTECT YOU AND THE PATIENT WHO RECIEVES YOUR BLOOD.",0,1);


$pdf->SetFont('Arial','',10);
$pdf->Cell(20,07,"Name :",0,0);
$pdf->Cell(80,07,$Name,0,0);
$pdf->Cell(15,07,"sex :",0,0);
$pdf->Cell(25,07,$sex,0,0);
$pdf->Cell(30,07,"Marital Status :",0,0);
$pdf->Cell(0,07,$marital_status,0,1);


$pdf->Cell(28,07,"Date of Birth :",0,0);
$pdf->Cell(37,07,$DOB,0,0);
$pdf->Cell(13,07,"Age :",0);
$pdf->Cell(22,07,$Age,0,0);
$pdf->Cell(50,07,"Father's/Husband's Name :",0,0);
$pdf->Cell(50,07,$Fname,0,1);


$pdf->Cell(25,07,"Occupation :",0,0);
$pdf->Cell(75,07,$Occupation,0,1);
// $pdf->Cell(25,07,"Organisation :",0,0);
// $pdf->Cell(0,07,$Org,0,1);

$pdf->Cell(20,07,"Address :",0,0);
$pdf->MultiCell(80,07,$Add,0,1);
// $pdf->SetCol($pdf->col+1);
// $pdf->Cell(23,07,"Personal No. :",0,0,);
// $pdf->Cell(25,07,$Pno,0,0,);
// $pdf->Cell(21,07,"Department :",0,0,);
// $pdf->Cell(31,07,$Dept,0,0,);


// $pdf->Cell(15,07,"Tel. No. :",0,0 );
// $pdf->Cell(35,07,$Tel,0,0);
// $pdf->Cell(20,07,"Mobile No. :",0,0);
// $pdf->Cell(30,07,$Mobile,0,1);


$pdf->Cell(25,07,"Blood Group. :",0,0);
$pdf->Cell(20,07,$B_group,0,);
$pdf->Cell(30,07,"Weight Category :",0,0);
$pdf->Cell(25,07,$Weight,0,1);
// $pdf->Cell(50,07,$Prate,0,0);
// $pdf->Cell(0,07,$Hb,0,1);


$pdf->Cell(75,07,"Blood Pressure : ",0,0,'R');
$pdf->Cell(25,07,$Bp,0,1);
// $pdf->Cell(30,07,"Temperature :- ",0,0);
// $pdf->Cell(30,07,$Temp,0,1);


$pdf->Cell(100,20,"Signature of the Reception Personnel.......",0,1);
// $pdf->Cell(30,10,$Mobile,0,1);
// $pdf->MultiCell(0,05,"I have read/understand allthe questions and have answered the questions (stated overleaf) myself and i agee todonate my blood Voluntarily",0,1);

$pdf->Cell(100,07,"I understand that: ",0,1);


// $pdf->MultiCell(100,07,"A.",0,0);
$pdf->MultiCell(100,5,"   A. Blood Donation is a voluntary and no inducement or remuneration been  offeren to me.",0,1);
// $pdf->Cell(0,3,"",0,1);


// $pdf->MultiCell(100,5,"B.",0,0);
$pdf->MultiCell(100,5,"   B. Donation of blood/component is a medical procedure and that by donating volunntary I accept the risk associated with the procedure.",0,1);
$pdf->Cell(0,3,"",0,1);


// $pdf->MultiCell(100,5,"C.",0,0);
$pdf->MultiCell(100,5,"   C. My blood will be tested for hepatitis B, hepatitis C, Malarial parasite, HIV/AIDS and venereal disease in additionto any other screening test required to ensure blood safety.",0,1);
$pdf->Cell(0,3,"",0,1);


$pdf->MultiCell(100,5,"I prohibit any information provided by me or about my donation to be disclosed to any individual or government agency without any prior permission.",0,0);

$pdf->MultiCell(0,5,"Signature/LTI of the Donor",0,1);




//Right Side of form.

$pdf->Cell(15,07,"sex :",0,0);
$pdf->Cell(25,07,$sex,0,0);
$pdf->Cell(30,07,"Marital Status :",0,0);
$pdf->Cell(0,07,$marital_status,0,1);

$pdf->Cell(50,07,"Father's/Husband's Name :",0,0);
$pdf->Cell(50,07,$Fname,0,1);

$pdf->Cell(25,07,"Organisation :",0,0);
$pdf->Cell(0,07,$Org,0,1);


$pdf->Cell(23,07,"Personal No. :",0,0,);
$pdf->Cell(25,07,$Pno,0,0);
$pdf->Cell(21,07,"Department :",0,0,);
$pdf->Cell(31,07,$Dept,0,1);


$pdf->Cell(15,07,"Tel. No. :",0,0 );
$pdf->Cell(35,07,$Tel,0,0);
$pdf->Cell(20,07,"Mobile No. :",0,0);
$pdf->Cell(30,07,$Mobile,0,1);

$pdf->Cell(50,07,$Prate,0,0);
$pdf->Cell(0,07,$Hb,0,1);


// $pdf->Cell(75,07,"Blood Pressure : ",0,0,'R');
// $pdf->Cell(25,07,$Bp,0,1);
$pdf->Cell(30,07,"Temperature :- ",0,0);
$pdf->Cell(30,07,$Temp,0,1);

$pdf->MultiCell(100,05,$Understand,0,1);





//Form-2 Pdf formating.



$pdf->Output();
ob_end_flush();
?>